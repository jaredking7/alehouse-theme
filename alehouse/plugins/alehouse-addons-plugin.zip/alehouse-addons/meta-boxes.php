<?php

$alehouse_meta_boxes = array();

/**
 * Slider meta box
 * Fields: slider image upload
*/ 
$alehouse_meta_boxes[] = array(
	'id' => 'alehouse-slider-meta-box',
	'title' => 'Slides',
	'pages' => array( 'alehouse_slider' ),
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array(
			'id' => 'alehouse_slider_upload',
			'name' => 'Upload Your Images',
			'desc' => 'Drag and drop files to reorder them.  Images should be 900x350 or larger.  Larger images will be cropped.',
			'type' => 'image_advanced',
		),
	),
);

/**
 * Gallery meta box
 * Fields: gallery image upload
*/ 
$alehouse_meta_boxes[] = array(
	'id' => 'alehouse-gallery-meta-box',
	'title' => 'Gallery',
	'pages' => array( 'alehouse_gallery' ),
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array(
			'id' => 'alehouse_gallery_upload',
			'name' => 'Upload Your Images',
			'desc' => 'Drag and drop files to reorder them.',
			'type' => 'image_advanced',
		),
	),
);

/**
 * Menu Meta Box
 * Fields: Item Name, Item Description, size and price
*/
$alehouse_meta_boxes[] = array(
	'id' => 'alehouse-menu-item-meta-box',
	'title' => 'Menu Item Details',
	'pages' => array( 'alehouse_menu_item' ),
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array(
			'id' => 'alehouse_menu_item_description',
			'name' => 'Menu Item Description',
			'desc' => '',
			'type' => 'wysiwyg',
		),
		array(
			'id' => 'alehouse_menu_item_price',
			'name' => 'Menu Item Price',
			'desc' => '',
			'type' => 'text',
		), 
	),
);

/**
 * Team Meta Box
 * Fields: name, position, email
*/
$alehouse_meta_boxes[] = array(
	'id' => 'alehouse-team-member-meta-box',
	'title' => 'Team Member Details',
	'pages' => array( 'alehouse_team_member' ),
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array(
			'id' => 'alehouse_team_member_position',
			'name' => 'Position',
			'desc' => '',
			'type' => 'text',
		),
		array(
			'id' => 'alehouse_team_member_email',
			'name' => 'Email',
			'desc' => '',
			'type' => 'text'
		),
		array(
			'id' => 'alehouse_team_member_about',
			'name' => 'About',
			'desc' => '',
			'type' => 'wysiwyg',
		),
	),
);

/**
 *	Register alehouse meta boxes
 */
function alehouse_register_meta_boxes() {
	global $alehouse_meta_boxes;
	
	if ( class_exists( 'RW_Meta_Box' ) ) {
		foreach ( $alehouse_meta_boxes as $meta_box ) {
			new RW_Meta_Box( $meta_box );
		}
	}
}

add_action( 'admin_init', 'alehouse_register_meta_boxes' );