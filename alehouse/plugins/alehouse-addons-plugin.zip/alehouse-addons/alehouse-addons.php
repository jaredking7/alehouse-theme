<?php
/*
Plugin Name: Alehouse Addons
Description: Adds custom post types for the Alehouse theme
Version: 1.0
Author: Jared King
Author URI: http://themeforest.net/user/JrodThemes?ref=JrodThemes
*/

// Make sure we don't expose any info if called directly
if ( ! function_exists( 'add_action' ) ) {
	exit;
}

function alehouse_custom_post_types() {
	
	// Menu
	$menu_labels = array(
		'name' => 'Menu Items',
		'singular_name' => __( 'Menu Item' ),
		'add_new' => 'Add New',
		'add_new_item' => 'Add New Menu Item',
		'edit_item' => 'Edit Menu Item',
		'new_item' => 'New Menu Item',
		'all_items' => 'All Menu Items',
		'view_item' => 'View Menu Item',
		'search_items' => 'Search Menu Items',
		'not_found' => 'No Menu Items Found',
		'not_found_in_trash' => 'No Menu Items Found in Trash',
	);
	
	$menu_args = array(
		'labels' => $menu_labels,
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => false,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'menu-item' ),
		'capability_type' => 'post',
		'has_archive' => false,
		'hierarchical' => false,
		'menu_position' => null,
		'menu_icon' => 'dashicons-menu',
		'supports' => array( 'title', 'thumbnail', 'page-attributes' ),
	);
	
	register_post_type( 'alehouse_menu_item', $menu_args ); 
	
	// Add Menu Item Category taxonomy
	$taxonomy_labels = array(
		'name' => _x( 'Menu Item Categories', 'taxonomy general name' ),
		'singular_name' => _x( 'Menu Item Category', 'taxonomy singular name' ),
		'search_items' => __( 'Search Menu Item Categories' ),
		'all_items' => __ ( 'All Menu Item Categories' ),
		'parent_item' => __( 'Parent Menu Item Category' ),
		'parent_item_colon' => __( 'Parent Menu Item Category:' ),
		'edit_item' => __( 'Edit Menu Item Category' ),
		'update_item' => __( 'Update Menu Item Category' ),
		'add_new_item' => __( 'Add New Menu Item Category' ),
		'new_item_name' => __( 'New Menu Item Category' ),
		'menu_name' => __( 'Menu Item Category' ),
	);
	
	$taxonomy_args = array(
		'hierarchical' => true,
		'labels' => $taxonomy_labels,
		'show_ui' => true,
		'show_admin_column' => '',
		'query_var' => true,
		'rewrite' => array( 'slug' => 'menu' ),
	);
	
	register_taxonomy( 'alehouse_menu_item_category', array( 'alehouse_menu_item' ), $taxonomy_args );
	
	// Gallery
	$gallery_labels = array(
		'name' => 'Galleries',
		'singular_name' => 'Gallery',
		'add_new' => 'Add New',
		'add_new_item' => 'Add New Gallery',
		'edit_item' => 'Edit Gallery',
		'new_item' => 'New Gallery',
		'all_items' => 'All Galleries',
		'view_item' => 'View Gallery',
		'search_items' => 'Search Galleries',
		'not_found' => 'No Galleries Found',
		'not_found_in_trash' => 'No Galleries Found in Trash',
	);
	
	$gallery_args = array (
		'labels' => $gallery_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => false,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'gallery' ),
		'capability_type' => 'post',
		'has_archive' => false,
		'hierarchical' => false,
		'menu_position' => null,
		'menu_icon' => 'dashicons-images-alt',
		'supports' => array( 'title', 'thumbnail', 'comments', 'page-attributes' ),
	);
	
	register_post_type( 'alehouse_gallery', $gallery_args );
	
	// Slider
	$slider_labels = array(
		'name' => 'Sliders',
		'singular_name' => 'Slider',
		'add_new' => 'Add New',
		'add_new_item' => 'Add New Slider',
		'edit_item' => 'Edit Slider',
		'new_item' => 'New Slider',
		'all_items' => 'All Sliders',
		'view_item' => 'View Slider',
		'search_items' => 'Search Sliders',
		'not_found' => 'No Sliders Found',
		'not_found_in_trash' => 'No Sliders Found in Trash',
	);
	
	$slider_args = array (
		'labels' => $slider_labels,
		'public' => false,
		'publicly_queryable' => false,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => false,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'slider' ),
		'capability_type' => 'post',
		'has_archive' => false,
		'hierarchical' => false,
		'menu_position' => null,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array( 'title' ),
	);
	
	register_post_type( 'alehouse_slider', $slider_args );
	
	// Team
	$team_labels = array(
		'name' => 'Team Members',
		'singular_name' => 'Team Member',
		'add_new' => 'Add New',
		'add_new_item' => 'Add New Team Member',
		'edit_item' => 'Edit Team Member',
		'new_item' => 'New Team Member',
		'all_items' => 'All Team Members',
		'view_item' => 'View Team Member',
		'search_items' => 'Search Team Members',
		'not_found' => 'No Team Members Found',
		'not_found_in_trash' => 'No Team Members Found in Trash',
	);
	
	$team_args = array (
		'labels' => $team_labels,
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => false,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'team-member' ),
		'capability_type' => 'post',
		'has_archive' => false,
		'hierarchical' => false,
		'menu_position' => null,
		'menu_icon' => 'dashicons-groups',
		'supports' => array( 'title', 'thumbnail', 'page-attributes' ),
	);
	
	register_post_type( 'alehouse_team_member', $team_args );

}

add_action( 'init', 'alehouse_custom_post_types' );

/**
 * Flush permalinks on plugin activation so users don't have to manually save permalinks
 */
function alehouse_rewrite_flush() {
	
	// make wordpress aware of our custom post types
	alehouse_custom_post_types();
	
	// flush the rules
	flush_rewrite_rules();
}

register_activation_hook( __FILE__, 'alehouse_rewrite_flush' );

/**
 *	Hook up the meta boxes script to our plugin
 */
define( 'RWMB_URL', trailingslashit( plugin_dir_url( __FILE__ ) . '/meta-box' ) );
define( 'RWMB_DIR', trailingslashit( plugin_dir_path(  __FILE__ ) . '/meta-box' ) );

require_once RWMB_DIR . 'meta-box.php';

/**
 * Meta boxes for our custom post types
 */
include plugin_dir_path( __FILE__ ) . '/meta-boxes.php';